/*
-- Query: select * from health_worker
LIMIT 0, 1000

-- Date: 2022-04-17 16:23
*/
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Ramana',1,1011,'Doctor','1980-01-01','male','A+','9381611371');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Ananya',2,1011,'Nurse','1981-01-25','Female','A-','9381611372');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Ruchira',3,1011,'Other','1984-05-01','Female','B+','9381611373');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Rithik',4,1012,'Doctor','1991-10-23','male','B-','9381611374');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Satvik',5,1012,'Nurse','1975-09-27','male','O+','9381611375');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Sushith',6,1012,'Other','1976-08-16','male','O-','9381611376');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Radhika',7,1021,'Doctor','1977-07-08','Female','AB+','9381611377');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Arpita',8,1021,'Nurse','1977-06-13','Female','AB-','9381611378');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Sahith',9,1021,'Other','1978-05-11','male','A+','9381611379');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Vishaka',10,1022,'Doctor','1988-04-14','Female','A-','9381611380');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Navin',11,1022,'Nurse','1987-01-18','male','B+','9381611381');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Murali',12,1022,'Other','1985-12-17','male','B-','9381611382');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Sharvary',13,1031,'Doctor','1990-11-21','Female','O+','9381611383');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Amit',14,1031,'Nurse','1991-01-31','male','O-','9381611384');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Aman',15,1031,'Other','1986-09-17','male','AB+','9381611385');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Likitha',16,1032,'Doctor','1987-08-08','Female','AB-','9381611386');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Rishitha',17,1032,'Nurse','1985-07-06','Female','A+','9381611387');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Pratham',18,1032,'Other','1987-06-05','male','A-','9381611388');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Sathvika',19,1041,'Doctor','1990-05-04','Female','B+','9381611389');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Rohit',20,1041,'Nurse','1988-04-09','male','A+','9381611390');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Rohitha',21,1041,'Other','1989-03-11','Female','O+','9381611391');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Roshan',22,1041,'Doctor','1970-02-13','male','A-','9381611392');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Roshitha',23,1042,'Nurse','1975-02-15','Female','A-','9381611393');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Raman',24,1042,'Other','1978-09-16','male','AB+','9381611394');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Kavish',25,1042,'Doctor','1979-06-19','male','A-','9381611395');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Srinivas',26,1052,'Nurse','1980-05-21','male','B+','9381611396');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Darshan',27,1052,'Other','1981-12-22','male','O-','9381611397');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Lavanya',28,1052,'Doctor','1982-11-23','Female','AB+','9381611398');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Samhitha',29,1061,'Nurse','1983-10-24','Female','A+','9381611399');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Prajesh',30,1061,'Other','1984-09-25','male','O-','9381611340');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Ajay',31,1061,'Doctor','1987-08-26','male','O+','9381611341');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Vineeta',32,1062,'Nurse','1982-08-27','Female','B+','9381611342');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Akash',33,1062,'Other','1986-07-28','male','O+','9381611343');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Aman',34,1062,'Doctor','1981-06-29','male','A+','9381611344');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Pratha',35,1071,'Nurse','1988-05-30','Female','O-','9381611345');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Seema',36,1071,'Other','1989-04-21','Female','B-','9381611346');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Adarsh',37,1071,'Doctor','1981-03-22','male','A-','9381611347');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Balaji',38,1072,'Nurse','1985-02-25','male','A-','9381611348');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Risabh',39,1072,'Other','1988-01-27','male','B+','9381611349');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Reema',40,1072,'Doctor','1989-12-18','Female','B-','9381611350');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Simar',41,1081,'Nurse','1990-11-17','Female','AB-','9381611351');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Aditi',42,1081,'Doctor','1991-10-13','Female','A-','9381611352');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Urvashi',43,1081,'Other','1979-09-11','Female','A+','9381611353');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Srujan',44,1082,'Doctor','1987-08-10','male','B+','9381611354');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Sujith',45,1082,'Nurse','1988-07-08','male','B-','9381611355');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Rahul',46,1082,'Other','1984-06-06','male','O+','9381611356');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Rohini',47,1091,'Doctor','1986-05-04','Female','O-','9381611357');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Saraswati',48,1092,'Doctor','1988-04-02','Female','O+','9381611358');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Karthik',49,1101,'Doctor','1989-03-19','male','A+','9381611359');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Akash',50,1102,'Doctor','1990-02-25','male','A+','9381611360');
INSERT INTO `` (`Name`,`Worker_ID`,`Hospital_ID`,`Role`,`DOB`,`Sex`,`Blood_Group`,`Contact`) VALUES ('Adarsh',51,1102,'Nurse','1991-01-28','male','A+','9381611361');
