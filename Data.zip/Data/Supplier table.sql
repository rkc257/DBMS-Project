/*
-- Query: select * from supplier
LIMIT 0, 1000

-- Date: 2022-04-17 10:33
*/
INSERT INTO `` (`Name`,`Supplier_ID`,`Conatct`) VALUES ('Vagdevi pvt ltd',1001,'9440556172');
INSERT INTO `` (`Name`,`Supplier_ID`,`Conatct`) VALUES ('LT pvt ltd',1002,'9440556173');
INSERT INTO `` (`Name`,`Supplier_ID`,`Conatct`) VALUES ('Vijay pvt ltd',1003,'9440556174');
INSERT INTO `` (`Name`,`Supplier_ID`,`Conatct`) VALUES ('Heeralal pvt ltd',1004,'9440556175');
INSERT INTO `` (`Name`,`Supplier_ID`,`Conatct`) VALUES ('Vishaka pvt ltd',1005,'9440556176');
INSERT INTO `` (`Name`,`Supplier_ID`,`Conatct`) VALUES ('radhika pvt ltd',1006,'9440556177');
INSERT INTO `` (`Name`,`Supplier_ID`,`Conatct`) VALUES ('ritesh pvt ltd',1007,'9440556178');
INSERT INTO `` (`Name`,`Supplier_ID`,`Conatct`) VALUES ('Animesh pvt ltd',1008,'9440556179');
INSERT INTO `` (`Name`,`Supplier_ID`,`Conatct`) VALUES ('Prajesh pvt ltd',1009,'9440556180');
INSERT INTO `` (`Name`,`Supplier_ID`,`Conatct`) VALUES ('EK pvt ltd',1010,'9440556181');
INSERT INTO `` (`Name`,`Supplier_ID`,`Conatct`) VALUES ('NMR pvt ltd',1011,'9440556182');
INSERT INTO `` (`Name`,`Supplier_ID`,`Conatct`) VALUES ('TRK pvt ltd',1012,'9440556183');
INSERT INTO `` (`Name`,`Supplier_ID`,`Conatct`) VALUES ('Swami pvt ltd',1013,'9440556184');
INSERT INTO `` (`Name`,`Supplier_ID`,`Conatct`) VALUES ('RR pvt ltd',1014,'9440556185');
INSERT INTO `` (`Name`,`Supplier_ID`,`Conatct`) VALUES ('Ambika pvt ltd',1015,'9440556186');
INSERT INTO `` (`Name`,`Supplier_ID`,`Conatct`) VALUES ('Rocky pvt ltd',1016,'9440556187');
INSERT INTO `` (`Name`,`Supplier_ID`,`Conatct`) VALUES ('Saraswati pvt ltd',1017,'9440556188');
INSERT INTO `` (`Name`,`Supplier_ID`,`Conatct`) VALUES ('MT pvt ltd',1018,'9440556189');
INSERT INTO `` (`Name`,`Supplier_ID`,`Conatct`) VALUES ('RFIC pvt ltd',1019,'9440556190');
INSERT INTO `` (`Name`,`Supplier_ID`,`Conatct`) VALUES ('Swastik pvt ltd',1020,'9440556191');
