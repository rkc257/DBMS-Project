/*
-- Query: select * from supplies
LIMIT 0, 1000

-- Date: 2022-04-17 12:51
*/
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1001,1011);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1002,1012);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1003,1021);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1004,1022);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1005,1031);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1006,1032);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1007,1041);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1008,1042);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1010,1052);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1011,1061);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1012,1062);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1013,1071);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1014,1072);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1015,1081);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1016,1082);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1017,1091);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1018,1092);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1019,1101);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1020,1102);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1002,1011);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1003,1011);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1004,1011);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1005,1011);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1006,1011);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1007,1011);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1008,1011);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1009,1011);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1010,1011);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1001,1012);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1003,1012);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1004,1012);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1005,1012);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1001,1021);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1006,1021);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1007,1021);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1008,1021);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1011,1022);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1012,1022);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1013,1022);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1014,1022);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1001,1031);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1002,1031);
INSERT INTO `` (`Supplier_ID`,`Hospital_ID`) VALUES (1003,1031);
