/*
-- Query: select * from variant
LIMIT 0, 1000

-- Date: 2022-04-17 14:29
*/
INSERT INTO `` (`Variant_name`,`Lineage`,`Symptoms`) VALUES ('Alpha','B.1.1.7','Fever,cough,shortness of breath, nausea, muscle pain, dizziness');
INSERT INTO `` (`Variant_name`,`Lineage`,`Symptoms`) VALUES ('Beta','B.1.351','Fever, headache, sore throat, sense of smell gone');
INSERT INTO `` (`Variant_name`,`Lineage`,`Symptoms`) VALUES ('Delta','B.1.617.2','Fever, headache, loss of appetie, severe flu');
INSERT INTO `` (`Variant_name`,`Lineage`,`Symptoms`) VALUES ('Omicron','B.1.1529','very mild symptom, no shortness of breath');
