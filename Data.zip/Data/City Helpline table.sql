/*
-- Query: select * from City_Helpline
LIMIT 0, 1000

-- Date: 2022-04-17 08:21
*/
INSERT INTO `` (`Pin`,`Helpline_no`) VALUES (101,'7032377216');
INSERT INTO `` (`Pin`,`Helpline_no`) VALUES (101,'7032377217');
INSERT INTO `` (`Pin`,`Helpline_no`) VALUES (102,'7032377218');
INSERT INTO `` (`Pin`,`Helpline_no`) VALUES (102,'7032377219');
INSERT INTO `` (`Pin`,`Helpline_no`) VALUES (103,'7032377220');
INSERT INTO `` (`Pin`,`Helpline_no`) VALUES (103,'7032377221');
INSERT INTO `` (`Pin`,`Helpline_no`) VALUES (104,'7032377222');
INSERT INTO `` (`Pin`,`Helpline_no`) VALUES (104,'7032377223');
INSERT INTO `` (`Pin`,`Helpline_no`) VALUES (105,'7032377224');
INSERT INTO `` (`Pin`,`Helpline_no`) VALUES (105,'7032377225');
INSERT INTO `` (`Pin`,`Helpline_no`) VALUES (106,'7032377226');
INSERT INTO `` (`Pin`,`Helpline_no`) VALUES (106,'7032377227');
INSERT INTO `` (`Pin`,`Helpline_no`) VALUES (107,'7032377228');
INSERT INTO `` (`Pin`,`Helpline_no`) VALUES (107,'7032377229');
INSERT INTO `` (`Pin`,`Helpline_no`) VALUES (108,'7032377230');
INSERT INTO `` (`Pin`,`Helpline_no`) VALUES (108,'7032377231');
INSERT INTO `` (`Pin`,`Helpline_no`) VALUES (109,'7032377232');
INSERT INTO `` (`Pin`,`Helpline_no`) VALUES (109,'7032377233');
INSERT INTO `` (`Pin`,`Helpline_no`) VALUES (110,'7032377234');
INSERT INTO `` (`Pin`,`Helpline_no`) VALUES (110,'7032377235');
INSERT INTO `` (`Pin`,`Helpline_no`) VALUES (110,'7032377236');
