/*
-- Query: select * from city
LIMIT 0, 1000

-- Date: 2022-04-17 08:07
*/
INSERT INTO `` (`Name`,`Pin`,`City_Incharge`,`State`) VALUES ('Hyderabad',101,'Ramulu','Telangana');
INSERT INTO `` (`Name`,`Pin`,`City_Incharge`,`State`) VALUES ('Kolokata',102,'Kamlesh','West Bengal');
INSERT INTO `` (`Name`,`Pin`,`City_Incharge`,`State`) VALUES ('Chennai',103,'Selvan','Tamil Nadu');
INSERT INTO `` (`Name`,`Pin`,`City_Incharge`,`State`) VALUES ('Gandhinagar',104,'Abhishek','Gujarat');
INSERT INTO `` (`Name`,`Pin`,`City_Incharge`,`State`) VALUES ('Patna',105,'Jignesh','Bihar');
INSERT INTO `` (`Name`,`Pin`,`City_Incharge`,`State`) VALUES ('Lucknow',106,'Fatima','Uttar Pradesh');
INSERT INTO `` (`Name`,`Pin`,`City_Incharge`,`State`) VALUES ('Bengaluru',107,'Marudappa','Karnataka');
INSERT INTO `` (`Name`,`Pin`,`City_Incharge`,`State`) VALUES ('Shimla',108,'Manish','Himachal Pradesh');
INSERT INTO `` (`Name`,`Pin`,`City_Incharge`,`State`) VALUES ('Jaipur',109,'Gajendra','Rajasthan');
INSERT INTO `` (`Name`,`Pin`,`City_Incharge`,`State`) VALUES ('Chandigarh',110,'Lal Singh','Punjab');
