/*
-- Query: select * from supply_details
LIMIT 0, 1000

-- Date: 2022-04-17 12:08
*/
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1001,501,5,1,'million');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1001,502,8,1,'million');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1001,503,1000,1,'lakh');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1001,504,5000,1.5,'lakh');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1002,504,4500,1,'lakh');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1002,505,10000,0.5,'lakh');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1003,501,4.5,1,'million');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1003,506,250,1,'cubic metres');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1004,506,199,0.25,'cubic metres');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1005,507,15,1,'million');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1005,508,50,4.5,'million');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1006,508,51,9,'million');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1006,509,400,1.5,'lakh');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1007,509,450,5,'lakh');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1007,510,350,8,'lakh');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1008,510,359,2.5,'lakh');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1008,511,100000,8,'thousand');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1009,511,50000,5,'hundred');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1010,512,100,1.5,'million');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1010,513,30,1.5,'lakh');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1011,512,99,5,'million');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1011,513,28,5,'lakh');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1012,514,100,1,'crore');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1013,514,105,5,'crore');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1013,515,1000,5,'lakh');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1014,515,1200,5,'lakh');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1015,501,6,9,'million');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1016,502,9,5,'million');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1017,512,99,5,'million');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1018,512,99,5,'million');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1019,512,99,5,'million');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1020,512,99,5,'million');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1016,506,250,1,'cubic metres');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1017,506,250,1,'cubic metres');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1018,506,250,1,'cubic metres');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1010,506,250,1,'cubic metres');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1008,506,250,1,'cubic metres');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1010,507,15,1,'million');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1015,507,15,1,'million');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1020,507,15,1,'million');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1008,504,4500,1,'lakh');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1010,504,4500,1,'lakh');
INSERT INTO `` (`Supplier_ID`,`Item_ID`,`Cost`,`Quantity`,`Units`) VALUES (1012,504,4500,1,'lakh');
