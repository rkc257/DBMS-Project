/*
-- Query: select * from items
LIMIT 0, 1000

-- Date: 2022-04-17 11:10
*/
INSERT INTO `` (`Name`,`Item_ID`,`Demand`,`Units`) VALUES ('3 Ply Face Mask',501,10,'million');
INSERT INTO `` (`Name`,`Item_ID`,`Demand`,`Units`) VALUES ('N95 Respiratory Mask',502,10,'million');
INSERT INTO `` (`Name`,`Item_ID`,`Demand`,`Units`) VALUES ('Oxygen Cylinder',503,2,'lakh');
INSERT INTO `` (`Name`,`Item_ID`,`Demand`,`Units`) VALUES ('Portable Oxygen Can',504,1,'lakh');
INSERT INTO `` (`Name`,`Item_ID`,`Demand`,`Units`) VALUES ('Oxygen concentrator',505,1,'lakh');
INSERT INTO `` (`Name`,`Item_ID`,`Demand`,`Units`) VALUES ('Oxygen refill',506,10,'cubic metres');
INSERT INTO `` (`Name`,`Item_ID`,`Demand`,`Units`) VALUES ('Oxygen mask',507,10,'million');
INSERT INTO `` (`Name`,`Item_ID`,`Demand`,`Units`) VALUES ('Surgical gloves',508,10,'million');
INSERT INTO `` (`Name`,`Item_ID`,`Demand`,`Units`) VALUES ('Infrared thermometer',509,10,'lakh');
INSERT INTO `` (`Name`,`Item_ID`,`Demand`,`Units`) VALUES ('Digital thermometer',510,10,'lakh');
INSERT INTO `` (`Name`,`Item_ID`,`Demand`,`Units`) VALUES ('ICU ventilator',511,10,'thousand');
INSERT INTO `` (`Name`,`Item_ID`,`Demand`,`Units`) VALUES ('Coronavirus Test kit',512,10,'crore');
INSERT INTO `` (`Name`,`Item_ID`,`Demand`,`Units`) VALUES ('Blood group Test kit',513,10,'million');
INSERT INTO `` (`Name`,`Item_ID`,`Demand`,`Units`) VALUES ('Covid medicine kit',514,10,'crore');
INSERT INTO `` (`Name`,`Item_ID`,`Demand`,`Units`) VALUES ('Oxy-pulse meter',515,10,'lakh');
