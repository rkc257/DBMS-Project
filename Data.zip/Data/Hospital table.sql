/*
-- Query: SELECT * FROM HOSPITAL
LIMIT 0, 1000

-- Date: 2022-04-17 12:18
*/
INSERT INTO `` (`Hospital_Name`,`Hospital_ID`,`Contact`,`Address`,`Pin`) VALUES ('Apex Hospital',1011,'8897876172','8-1-21,karmanghat,500079',101);
INSERT INTO `` (`Hospital_Name`,`Hospital_ID`,`Contact`,`Address`,`Pin`) VALUES ('KIMS Hospital',1012,'8897876173','5-12-41,LB Nagar,500035',101);
INSERT INTO `` (`Hospital_Name`,`Hospital_ID`,`Contact`,`Address`,`Pin`) VALUES ('Rainbow Hospital',1021,'8897876174','6-87,VIP Road,700052',102);
INSERT INTO `` (`Hospital_Name`,`Hospital_ID`,`Contact`,`Address`,`Pin`) VALUES ('Nightingale Hospital',1022,'8897876175','7-41,Bijoygarh,700032',102);
INSERT INTO `` (`Hospital_Name`,`Hospital_ID`,`Contact`,`Address`,`Pin`) VALUES ('Krishna Hospital',1031,'8897876176','4-12-41,Ethiraj Salai,600008',103);
INSERT INTO `` (`Hospital_Name`,`Hospital_ID`,`Contact`,`Address`,`Pin`) VALUES ('Yash Hospital',1032,'8897876177','5-8-17,Flowers Road,600084',103);
INSERT INTO `` (`Hospital_Name`,`Hospital_ID`,`Contact`,`Address`,`Pin`) VALUES ('Rudra Hospital',1041,'8897876178','5/2,Balipur Road,382421',104);
INSERT INTO `` (`Hospital_Name`,`Hospital_ID`,`Contact`,`Address`,`Pin`) VALUES ('Shiva Hospital',1042,'8897876179','8/17,Divine Park,380060',104);
INSERT INTO `` (`Hospital_Name`,`Hospital_ID`,`Contact`,`Address`,`Pin`) VALUES ('Sagar Hospital',1052,'8897876181','7/12,Atnama,803213',105);
INSERT INTO `` (`Hospital_Name`,`Hospital_ID`,`Contact`,`Address`,`Pin`) VALUES ('Liberty Hospital',1061,'8897876182','5/7,Aunta,803303',105);
INSERT INTO `` (`Hospital_Name`,`Hospital_ID`,`Contact`,`Address`,`Pin`) VALUES ('City Hospital',1062,'8897876183','7/12,Alamnagar,226017',106);
INSERT INTO `` (`Hospital_Name`,`Hospital_ID`,`Contact`,`Address`,`Pin`) VALUES ('Narayan Hospital',1071,'8897876184','8/16,Alambagh,226005',106);
INSERT INTO `` (`Hospital_Name`,`Hospital_ID`,`Contact`,`Address`,`Pin`) VALUES ('Apollo Hospital',1072,'8897876185','12/41,Brigade Road,560001',107);
INSERT INTO `` (`Hospital_Name`,`Hospital_ID`,`Contact`,`Address`,`Pin`) VALUES ('Fortis Hospital',1081,'8897876186','5/41,Bommanahalli,560068',107);
INSERT INTO `` (`Hospital_Name`,`Hospital_ID`,`Contact`,`Address`,`Pin`) VALUES ('Apollo Hospital',1082,'8897876187','8/21,Bychari,171011',108);
INSERT INTO `` (`Hospital_Name`,`Hospital_ID`,`Contact`,`Address`,`Pin`) VALUES ('Vedanta Hospital',1091,'8897876188','5/4,Cpri,171001',108);
INSERT INTO `` (`Hospital_Name`,`Hospital_ID`,`Contact`,`Address`,`Pin`) VALUES ('Fortis Hospital',1092,'8897876189','1/3,Amer,302028',109);
INSERT INTO `` (`Hospital_Name`,`Hospital_ID`,`Contact`,`Address`,`Pin`) VALUES ('Amar Hospital',1101,'8897876190','2/9,Badheri,160036',110);
INSERT INTO `` (`Hospital_Name`,`Hospital_ID`,`Contact`,`Address`,`Pin`) VALUES ('Aditya Hospital',1102,'8897876191','5/1,Balongi,140301',110);
