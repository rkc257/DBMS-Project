/*
-- Query: select * from death
LIMIT 0, 1000

-- Date: 2022-04-18 10:57
*/
INSERT INTO `` (`Patient_ID`,`Death_reason`,`Days_stayed`) VALUES (1,'Cardiac arrest',13);
INSERT INTO `` (`Patient_ID`,`Death_reason`,`Days_stayed`) VALUES (8,'Multi-organ failure',21);
INSERT INTO `` (`Patient_ID`,`Death_reason`,`Days_stayed`) VALUES (15,'Respiratory failure',14);
INSERT INTO `` (`Patient_ID`,`Death_reason`,`Days_stayed`) VALUES (18,'Pneumonia',11);
INSERT INTO `` (`Patient_ID`,`Death_reason`,`Days_stayed`) VALUES (45,'gastric peptic ulcer',18);
INSERT INTO `` (`Patient_ID`,`Death_reason`,`Days_stayed`) VALUES (85,'Cardiac arrest',7);
INSERT INTO `` (`Patient_ID`,`Death_reason`,`Days_stayed`) VALUES (93,'Respiratory failure',6);
INSERT INTO `` (`Patient_ID`,`Death_reason`,`Days_stayed`) VALUES (98,'Cardiac arrest',15);
INSERT INTO `` (`Patient_ID`,`Death_reason`,`Days_stayed`) VALUES (101,'Multi-organ failure',19);
INSERT INTO `` (`Patient_ID`,`Death_reason`,`Days_stayed`) VALUES (102,'Respiratory failure',21);
INSERT INTO `` (`Patient_ID`,`Death_reason`,`Days_stayed`) VALUES (104,'gastric peptic ulcer',27);
